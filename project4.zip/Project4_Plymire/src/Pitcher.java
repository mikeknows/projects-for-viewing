/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mike
 */
public class Pitcher {
    double missedpitches = 0;
    double pitchstrike = 0;
   private String name;
   private double average;

    public double getMissedpitches() {
        return missedpitches;
    }

    public void setMissedpitches(double missedpitches) {
        this.missedpitches = missedpitches;
    }

    public double getPitchstrike() {
        return pitchstrike;
    }

    public void setPitchstrike(double pitchstrike) {
        this.pitchstrike = pitchstrike;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }
   
   public boolean pitch(){
   
       if(missedpitches == 0 || missedpitches < average ){
           check++;
           return false;
           
       }else{
           return true;
           
       }
   }
    
}
